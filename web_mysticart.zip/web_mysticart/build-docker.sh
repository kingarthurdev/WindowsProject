#!/bin/bash
docker rm -f web_mysticart
docker build -t web_mysticart .
docker run --name=web_mysticart --rm -p1337:1337 -it web_mysticart