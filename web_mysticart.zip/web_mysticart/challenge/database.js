const sqlite = require("sqlite-async");

class Database {
  constructor(db_file) {
    this.db_file = db_file;
    this.db = undefined;
  }

  async connect() {
    this.db = await sqlite.open(this.db_file);
  }

  async migrate() {
    return this.db.exec(`
      DROP TABLE IF EXISTS products;
      DROP TABLE IF EXISTS comments;

      CREATE TABLE products(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name VARCHAR(255) NOT NULL,
          description TEXT NOT NULL,
          price VARCHAR(255) NOT NULL,
          image VARCHAR(255) NOT NULL
      );

			CREATE TABLE comments(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				product VARCHAR(255) NOT NULL,
				comment TEXT NOT NULL
			);

      INSERT INTO products (name, description, price, image) VALUES
      ('Arcane Tomb', 'Delve into the arcane as you explore this Arcane Tomb. Within its ancient, rune-etched covers lies a compendium of forgotten spells and sorcerous knowledge that once shaped the very fabric of the magical realms.', '$10', '/static/images/arcane_tomb.webp');

      INSERT INTO products (name, description, price, image) VALUES
      ('Boundless Cloak', 'Enshroud yourself in the mysteries of the universe with the Boundless Cloak. Crafted from ethereal fabrics that glimmer with celestial light, this cloak is said to be a key to crossing the thresholds that bind the mortal planes.', '$9', '/static/images/cloak.webp');

      INSERT INTO products (name, description, price, image) VALUES
      ('Divine Jewel', 'Possessing a core of concentrated ethereality, the Divine Jewel pulses with a light that mirrors the stars themselves. It is more than an ornament; it is a bastion of purity that shields the wearer from darkness.', '$9', '/static/images/divine_jewel.webp');

      INSERT INTO products (name, description, price, image) VALUES
      ('Dragon', 'Behold the grandeur of the mythical beast with this intricately detailed Dragon sculpture. Cast from the forges of elder craftsmen, this piece captures the awe-inspiring presence of dragons in their primeval glory.', '$9', '/static/images/dragon.webp');

      INSERT INTO products (name, description, price, image) VALUES
      ('Eternal Potion', 'Imbibe the swirling, iridescent liquid of the Eternal Potion and feel the tides of endless time coursing through your veins. A draught from this vial promises the bearer fleeting visions of the infinite.', '$12', '/static/images/eternal_potion.webp');

      INSERT INTO products (name, description, price, image) VALUES
      ('Holy Compass', "The Holy Compass does not just point north, but to one's destiny. With an ornate dial and a needle that quivers with spiritual energy, this compass seeks the truth hidden within the soul of its holder.", '$5', '/static/images/holy_compass.webp');

      INSERT INTO products (name, description, price, image) VALUES
      ('Majestic Wand', 'The Majestic Wand, resplendent with its jewel-encrusted handle, channels the arcane currents that flow unseen around us. To wield it is to command the respect of the elements and the spirits that dwell beyond.', '$15', '/static/images/Majestic_Wand.webp');

      INSERT INTO products (name, description, price, image) VALUES
      ('Divine Sword', 'Forged in the empyrean flames that burn in celestial forges, the Divine Sword is the bane of malevolence. Its blade gleams with a holy light, a testament to its creation for champions of the light.', '$5', '/static/images/divin_sword.webp');

      -- Placeholder comments for each product (assuming product names are unique identifiers here)
      INSERT INTO comments (product, comment) VALUES
      ('1', "This tome is absolutely enthralling! The spells contained within are unlike anything I've ever seen.");

      INSERT INTO comments (product, comment) VALUES
      ('2', 'The cloak is not only stunning to look at, but it also has an aura of mystery. I feel like I could walk between worlds!');

      INSERT INTO comments (product, comment) VALUES
      ('3', 'Wearing the Divine Jewel makes me feel at peace, as if I am shielded by the light of the heavens.');

      INSERT INTO comments (product, comment) VALUES
      ('4', 'The detail on this dragon sculpture is impeccable. It feels as though it might come to life at any moment.');

      INSERT INTO comments (product, comment) VALUES
      ('5', 'After tasting the Eternal Potion, I felt a brief connection with the cosmos that I will never forget.');

      INSERT INTO comments (product, comment) VALUES
      ('6', 'The Holy Compass is a remarkable piece. It seems to point me towards choices I never knew I had.');

      INSERT INTO comments (product, comment) VALUES
      ('7', 'With the Majestic Wand in hand, I can almost feel the arcane energy ready to answer my call.');

      INSERT INTO comments (product, comment) VALUES
      ('8', 'The Divine Sword is truly a masterpiece. Its edge is keen, and its presence is awe-inspiring.');
`);
  }

  async add_comments(for_product, comment) {
    return new Promise(async (resolve, reject) => {
      try {
        let stmt = await this.db.prepare(
          "INSERT INTO comments (product, comment) VALUES (?, ?)"
        );
        resolve(
          await stmt.run(for_product, comment)
        );
      } catch (e) {
        reject(e);
      }
    });
  }

  async get_products() {
    return new Promise(async (resolve, reject) => {
      try {
        let stmt = await this.db.prepare("SELECT * FROM products");
        resolve(await stmt.all());
      } catch (e) {
        reject(e);
      }
    });
  }

  async get_product(prod_id) {
    return new Promise(async (resolve, reject) => {
      try {
        let stmt = await this.db.prepare("SELECT * FROM products WHERE id=?");
        resolve(await stmt.all(prod_id));
      } catch (e) {
        reject(e);
      }
    });
  }

  async get_comments(prod_id) {
    return new Promise(async (resolve, reject) => {
      try {
        let stmt = await this.db.prepare("SELECT * FROM comments WHERE product=?");
        resolve(await stmt.all(prod_id));
      } catch (e) {
        reject(e);
      }
    });
  }
}

module.exports = Database;
