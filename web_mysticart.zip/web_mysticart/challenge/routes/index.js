const express = require('express');
const router = express.Router({ caseSensitive: true });
const bot = require('../bot');

let db;

const response = data => ({ message: data });

router.get('/', (req, res) => {
    return db.get_products()
    .then((data) => {
        console.log(data)
        return res.render('index.html', {products: data});
    })
    .catch(() => res.send(response('Something Went Wrong!')));
});

router.get('/product/:id', (req, res) => {
    let prod_id = req.params.id
    return db.get_product(prod_id)
    .then((data) => {
        console.log(data)
        return res.render('product.html', {product: data[0]});
    })
    .catch(() => res.send(response('Something Went Wrong!')));
});

router.get('/report/:id', (req, res) => {
    let prod_id = req.params.id;
    bot.visit(prod_id);
    return res.send(response("OK"));
});

router.get('/comments/:id', (req, res) => {
    let prod_id = req.params.id
    return db.get_comments(prod_id)
    .then((data) => {
        console.log(data)
        return res.send({ comments: data });
    })
    .catch(() => res.send(response('Something Went Wrong!')));
});

router.post('/comments/:id', (req, res) => {
    let prod_id = req.params.id
    const { comment } = req.body;

    return db.add_comments(prod_id, comment)
    .then(() => {
        return res.send(response('OK'));
    })
    .catch(() => res.send(response('Something Went Wrong!')));
});


module.exports = database => {
    db = database;
    return router;
};