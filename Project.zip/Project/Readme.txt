ConsoleApp3: The console client application
dotNetClassLibrary: Contains the ProcessContent class
dotNetService: Listens for any requests on port 12000, responds with generic ack. (verifying the request and responding with appropriate real data will be implemented later) 

